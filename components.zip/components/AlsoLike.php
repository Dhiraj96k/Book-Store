<?php
    function AlsoLike($sql)
    {
        echo '
        
             ';
    }
?>